package com.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UserDashBoardPage {
	
	private WebDriver driver;
	private By DashBoard = By.cssSelector("div#header-wrap nav");
	public UserDashBoardPage (WebDriver driver) {
		this.driver = driver;
		}
	public String getUserDashboardTitle() {
		return driver.getTitle();
		
	}
	
	  
	
	public int userDashboardfeaturescount() {
		return driver.findElements(DashBoard).size()-1;
		
		}
	public List<String> userDashboardList() {
		List<String> dashboardList = new ArrayList<>();
		List<WebElement> userdashboardList = driver.findElements(DashBoard);
		for(WebElement e : userdashboardList) {
		String text =	e.getText();
		System.out.println(text);
		dashboardList.add(text);
			}
		
		return dashboardList;
		
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
