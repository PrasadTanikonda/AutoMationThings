package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UserMemberLoginPage {
	
	private WebDriver driver;
	//1.By Locaters :
	private By username = By.id("txtUserName");
	private By password= By.id("txtPassword");   
    private By Login = By.id("login-form-submit");
    private By ForgotPassword = By.linkText("Forgot password ?");
    private By RegisterHere = By.linkText(":: Register Here ::");	
	
	//2. Constructor of the page class 
	
	public UserMemberLoginPage(WebDriver driver) {
		this.driver = driver;
	}
	
//3. page actions: features (behavior) of the page the from the methods
	
	public String  getLoginPageTitle() {
		return driver.getTitle();
		
		
		}
	public void enteUserName(String UserId) {
		driver.findElement(username).sendKeys(UserId);
	}
	public void passWord(String pwd) {
		driver.findElement(password).sendKeys(pwd);
		}
	public void clickOnLogin() {
		driver.findElement(Login).click();
    }
    public boolean isForgotPasswordExist() {
    	return driver.findElement(ForgotPassword).isDisplayed();
		
		}
    public boolean CheckRegisterHere() {
    	return driver.findElement(RegisterHere).isDisplayed();
    }
    
    public void SeleniumWait() {
    	
    	
    	
    }
    
    public UserDashBoardPage doLogin(String un, String pwd) {
    	System.out.println("Login with: " + un + "and" + pwd );
    	
    	driver.findElement(username).sendKeys(un);
    	driver.findElement(password).sendKeys(pwd);
    	driver.findElement(Login).click();
    	return new UserDashBoardPage(driver);
    	
    	
    }
	
	
	
	
}
