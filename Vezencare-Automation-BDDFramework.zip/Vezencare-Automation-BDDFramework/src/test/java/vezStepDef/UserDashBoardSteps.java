package vezStepDef;

import static org.junit.Assert.assertArrayEquals;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.pages.UserDashBoardPage;
import com.pages.UserMemberLoginPage;
import com.qa.factory.DriverFactory;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UserDashBoardSteps {
	private static String title;
	private UserMemberLoginPage umlp = new UserMemberLoginPage(DriverFactory.getDriver());
	private UserDashBoardPage userDashBoard;
	
	
	
	@Given("user has already logged in to application")
	public void user_has_already_logged_in_to_application(DataTable CredTable) {
		
		List<Map<String, String>> CredList = CredTable.asMaps();
		String userName = CredList.get(0).get("username");
		String password = CredList.get(1).get("password");
		DriverFactory.getDriver().get("https://qa.vezencare.com/Home/UserLogin");
		userDashBoard= umlp.doLogin(userName, password);
	    
	}

	//@Given("user is on UserDashBoard page"){
		//DriverFactory.getDriver().get("https://qa.vezencare.com/Home/UserLogin");
		//userDashBoard= umlp.doLogin(userName, password);
	
		
	

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		String title = userDashBoard.getUserDashboardTitle();
		System.out.println("Page title is: " + title);
	    
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String  expectedTitleName) {
		Assert.assertTrue(title.contains(expectedTitleName));
	    
	}

	@Then("user gets UserDashBoard features section")
	public void user_gets_user_dash_board_features_section(DataTable featuresTable) {
		
		List<String>ExpectedFeaturesList= featuresTable.asList();
		System.out.println("expected List :" + ExpectedFeaturesList);
		List<String> AcctualFeaturesList =userDashBoard.userDashboardList();
		System.out.println("AcctualList:" + AcctualFeaturesList );
		Assert.assertTrue(ExpectedFeaturesList.contains(AcctualFeaturesList));

		
	    
	}

	@Then("user features  section count should be {int}")
	public void user_features_section_count_should_be(Integer expectedlList) {
		Assert.assertTrue(userDashBoard.userDashboardfeaturescount() == expectedlList);
		
		
		//Assert.assertTrue(userDashBoard.userDashboardfeaturescount() == expectedlList);   
		
	    
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
