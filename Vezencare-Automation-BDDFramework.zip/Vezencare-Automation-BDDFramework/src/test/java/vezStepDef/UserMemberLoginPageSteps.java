package vezStepDef;

import org.junit.Assert;

import com.pages.UserMemberLoginPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UserMemberLoginPageSteps {
	private static  String title;
	
	private UserMemberLoginPage umlp = new UserMemberLoginPage(DriverFactory.getDriver());
	
	
	
	@Given("I navigate to user login page")
	public void i_navigate_to_user_login_page() throws InterruptedException {
		
		DriverFactory.getDriver().get("https://qa.vezencare.com/Home/UserLogin");
		Thread.sleep(10000);
	 
	}

	@When("I navigate to login page gets the title of page")
	public void i_navigate_to_login_page_gets_the_title_of_page() {
		String title =	umlp.getLoginPageTitle();
		System.out.println("login page title is:"+ title);
	    
	    }
 @Then("Page title should be {string}")
	public void page_title_should_be(String expectedtitle) {
	    Assert.assertTrue(title.contains(expectedtitle));
		
	}
   @When("I login with valid username{string} and password{string}")
	public void i_login_with_valid_user_name_and_password(String username,String pwd) {
	    umlp.enteUserName(username);
	    umlp.passWord(pwd);
	    umlp.clickOnLogin();
	    
	}

	@Then("user should be navigate to member dashboard successfully")
	public void user_should_be_navigate_to_member_dashboard_successfully() {
	    
	}

	@When("I see and click on register here")
	public void i_see_and_click_on_register_here() {
	    
	}

	@Then("I should navigate to register here page with required fields")
	public void i_should_navigate_to_register_here_page_with_required_fields() {
	    
	}

	@When("I see and click on forgot password option")
	public void i_see_and_click_on_forgot_password_option() {
	    
	}

	@Then("I should navigate to fogot password page")
	public void i_should_navigate_to_fogot_password_page() {
	    
	}

}
