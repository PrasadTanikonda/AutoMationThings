package Vezen.Application.Hooks;

import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.yaml.snakeyaml.emitter.ScalarAnalysis;

import com.qa.factory.DriverFactory;
import com.qa.util.ConfigReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class VezenAppHooks {
	
	
	private DriverFactory driverfactory;
	private WebDriver driver;
	private ConfigReader configReader;
	Properties  prop;
	
	@Before(order=0)
	public void getProperty() {
		configReader = new ConfigReader();
		prop=configReader.init_Prop();
	}
	@Before(order=1)
	public void LaunchBrowser() {
		
		String browseName =prop.getProperty("browser");
		driverfactory = new DriverFactory();
		driver=driverfactory.init_driver(browseName);
	}
	
  // @Before(order=2)	
   //public void Waitbrowser() throws InterruptedException {
	   
	 //  driver.wait(5000);
	   
  // }
		
	
	@After(order=0)
	public void quitBrowser() {
		driver.quit();
	}
	@After(order=1)
	public void tearDown(Scenario scenario) {
		
		if(scenario.isFailed()) {
		// Take Screen Short 
			String screenshotname  =scenario.getName().replaceAll("", "_");
			byte[] sourcepath= ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(sourcepath, "image/png", screenshotname);
			
		}
	}
		
	}
	
	
	
	


