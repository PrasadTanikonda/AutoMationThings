$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "e076ac08-5563-487d-8372-bf2033e6f002",
    "feature": "UserMemberLoginPage Feature",
    "scenario": "Verify user member login - Valid",
    "start": 1638676569428,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1638676580291,
    "className": "undefined"
  },
  {
    "id": "8b3cf93b-8a4d-4735-9a07-a704c572e0c5",
    "feature": "UserDashBoard Feature",
    "scenario": "UserDashBoard page title",
    "start": 1638676470423,
    "group": 1,
    "content": "",
    "tags": "@userdashboard,",
    "end": 1638676515657,
    "className": "failed"
  },
  {
    "id": "fca9a57f-4546-4eb5-b612-c04a8cb405de",
    "feature": "UserMemberLoginPage Feature",
    "scenario": "UserMember LoginPage title",
    "start": 1638676531923,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1638676569377,
    "className": "failed"
  },
  {
    "id": "36925f2a-86c4-4dae-b12f-96ce2ff91792",
    "feature": "UserMemberLoginPage Feature",
    "scenario": "Verify forgot password",
    "start": 1638676587743,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1638676594717,
    "className": "passed"
  },
  {
    "id": "0c4ddd28-99ab-431c-b3a3-12f55c65d791",
    "feature": "UserMemberLoginPage Feature",
    "scenario": "Verify Register here",
    "start": 1638676580300,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1638676587734,
    "className": "passed"
  },
  {
    "id": "cd7fbec2-af91-4d2d-9756-6a8ecf063622",
    "feature": "UserDashBoard Feature",
    "scenario": "UserDashBoard features count",
    "start": 1638676515708,
    "group": 1,
    "content": "",
    "tags": "@userdashboard,",
    "end": 1638676531910,
    "className": "failed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});